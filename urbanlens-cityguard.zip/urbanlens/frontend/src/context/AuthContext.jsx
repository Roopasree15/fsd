// ============================================================
// context/AuthContext.jsx - Global authentication state
// ============================================================
import { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true); // true on first load

  // On app start: restore user from localStorage
  useEffect(() => {
    const storedToken = localStorage.getItem('urbanlens_token');
    const storedUser = localStorage.getItem('urbanlens_user');
    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  // ── Login ─────────────────────────────────────────────────
  const login = async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password });
    setUser(data.user);
    setToken(data.token);
    localStorage.setItem('urbanlens_token', data.token);
    localStorage.setItem('urbanlens_user', JSON.stringify(data.user));
    return data;
  };

  // ── Signup ────────────────────────────────────────────────
  const signup = async (name, email, password) => {
    const { data } = await api.post('/auth/signup', { name, email, password });
    setUser(data.user);
    setToken(data.token);
    localStorage.setItem('urbanlens_token', data.token);
    localStorage.setItem('urbanlens_user', JSON.stringify(data.user));
    return data;
  };

  // ── Logout ────────────────────────────────────────────────
  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('urbanlens_token');
    localStorage.removeItem('urbanlens_user');
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider value={{ user, token, loading, login, signup, logout, isAdmin }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook for easy access to auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

// ============================================================
// utils/api.js - Axios instance with auth interceptor
// ============================================================
import axios from 'axios';

// Create axios instance pointing to the backend
const api = axios.create({
  baseURL: '/api', // Uses Vite proxy in dev, set full URL in production
  timeout: 10000,
});

// ── Request Interceptor ───────────────────────────────────────
// Automatically attach JWT token to every request if it exists
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('urbanlens_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response Interceptor ──────────────────────────────────────
// Handle 401 errors globally (token expired / invalid)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Clear local storage and redirect to login
      localStorage.removeItem('urbanlens_token');
      localStorage.removeItem('urbanlens_user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;

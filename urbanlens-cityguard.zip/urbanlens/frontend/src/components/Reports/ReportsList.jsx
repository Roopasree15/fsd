// ============================================================
// components/Reports/ReportsList.jsx
// Filterable, sortable list of all city issue reports
// ============================================================
import { useState, useEffect } from 'react';
import api from '../../utils/api';

// ── Constants ────────────────────────────────────────────────
const TYPE_BADGE = {
  Theft:          'badge-theft',
  Drainage:       'badge-drainage',
  'Street Light': 'badge-light',
  Climate:        'badge-climate',
};
const STATUS_BADGE = {
  Pending:      'badge-pending',
  'In Progress':'badge-progress',
  Resolved:     'badge-resolved',
};
const TYPE_DOT = {
  Theft:          '#ef4444',
  Drainage:       '#3b82f6',
  'Street Light': '#f59e0b',
  Climate:        '#10b981',
};

// ── Report Row sub-component ──────────────────────────────────
function ReportRow({ report, index }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <>
      <tr
        onClick={() => setExpanded(!expanded)}
        className={`border-b border-white/5 cursor-pointer transition-colors
          hover:bg-dark-700/50 ${index % 2 === 0 ? '' : 'bg-dark-800/20'}`}
      >
        {/* Issue type */}
        <td className="px-4 py-3.5">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full flex-shrink-0"
              style={{ background: TYPE_DOT[report.issueType] || '#6b7280',
                       boxShadow: `0 0 5px ${TYPE_DOT[report.issueType] || '#6b7280'}70` }} />
            <span className={`text-xs px-2 py-0.5 rounded-full ${TYPE_BADGE[report.issueType] || ''}`}>
              {report.issueType}
            </span>
          </div>
        </td>

        {/* Location */}
        <td className="px-4 py-3.5">
          <span className="text-sm text-gray-300 max-w-[140px] truncate block">{report.location}</span>
        </td>

        {/* Description (truncated) */}
        <td className="px-4 py-3.5 hidden md:table-cell">
          <span className="text-sm text-gray-400 max-w-[220px] truncate block">{report.description}</span>
        </td>

        {/* Reported by */}
        <td className="px-4 py-3.5 hidden lg:table-cell">
          <span className="text-sm text-gray-400">{report.user?.name || '—'}</span>
        </td>

        {/* Severity */}
        <td className="px-4 py-3.5 hidden sm:table-cell">
          <span className="text-xs text-gray-500">{report.severity}</span>
        </td>

        {/* Status */}
        <td className="px-4 py-3.5">
          <span className={`text-xs px-2 py-0.5 rounded-full ${STATUS_BADGE[report.status] || ''}`}>
            {report.status}
          </span>
        </td>

        {/* Date */}
        <td className="px-4 py-3.5 hidden xl:table-cell">
          <span className="text-xs text-gray-600">
            {new Date(report.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: '2-digit' })}
          </span>
        </td>

        {/* Expand icon */}
        <td className="px-4 py-3.5 text-right">
          <span className={`text-gray-600 text-xs transition-transform inline-block ${expanded ? 'rotate-180' : ''}`}>▼</span>
        </td>
      </tr>

      {/* Expanded detail row */}
      {expanded && (
        <tr className="bg-dark-700/30 border-b border-white/5">
          <td colSpan={8} className="px-6 py-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-xs font-mono text-gray-500 uppercase tracking-wider">Full Description</p>
                <p className="text-sm text-gray-300 leading-relaxed">{report.description}</p>
                {report.adminNote && (
                  <div className="mt-2 p-2 bg-accent-cyan/5 border border-accent-cyan/15 rounded-lg">
                    <p className="text-xs font-mono text-gray-500 mb-1">ADMIN NOTE</p>
                    <p className="text-sm text-gray-300">{report.adminNote}</p>
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <p className="text-xs font-mono text-gray-500 uppercase tracking-wider">Details</p>
                <div className="text-xs space-y-1.5">
                  <div className="flex gap-2">
                    <span className="text-gray-600 w-20">Location</span>
                    <span className="text-gray-300">{report.location}</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-gray-600 w-20">Coords</span>
                    <span className="text-gray-400 font-mono">
                      {report.coordinates?.lat?.toFixed(5)}, {report.coordinates?.lng?.toFixed(5)}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-gray-600 w-20">Severity</span>
                    <span className="text-gray-300">{report.severity}</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-gray-600 w-20">Updated</span>
                    <span className="text-gray-400">{new Date(report.updatedAt).toLocaleDateString()}</span>
                  </div>
                </div>
                {/* Image thumbnail */}
                {report.image && (
                  <img
                    src={`/uploads/${report.image}`}
                    alt="Report evidence"
                    className="w-full max-w-[200px] h-28 object-cover rounded-lg border border-white/10 mt-2"
                  />
                )}
              </div>
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

// ── Main Component ────────────────────────────────────────────
export default function ReportsList() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ issueType: '', status: '' });
  const [search,  setSearch]  = useState('');
  const [total,   setTotal]   = useState(0);

  const fetchReports = async () => {
    setLoading(true);
    try {
      const params = { limit: 100 };
      if (filters.issueType) params.issueType = filters.issueType;
      if (filters.status)    params.status    = filters.status;

      const { data } = await api.get('/reports', { params });
      setReports(data.reports);
      setTotal(data.total);
    } catch (err) {
      console.error('Failed to fetch reports:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchReports(); }, [filters]);

  // Client-side search filter
  const filtered = reports.filter((r) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      r.location?.toLowerCase().includes(q)    ||
      r.description?.toLowerCase().includes(q) ||
      r.issueType?.toLowerCase().includes(q)   ||
      r.user?.name?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-5 animate-fade-in">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white">All Reports</h1>
          <p className="text-gray-500 text-sm mt-0.5">
            Showing {filtered.length} of {total} total reports
          </p>
        </div>
        {/* Stats pills */}
        <div className="flex gap-2 flex-wrap">
          {['Pending', 'In Progress', 'Resolved'].map((s) => {
            const cnt = reports.filter((r) => r.status === s).length;
            return (
              <button
                key={s}
                onClick={() => setFilters((f) => ({ ...f, status: f.status === s ? '' : s }))}
                className={`text-xs px-3 py-1 rounded-full border transition-all ${
                  filters.status === s
                    ? s === 'Pending' ? 'badge-pending' : s === 'In Progress' ? 'badge-progress' : 'badge-resolved'
                    : 'border-white/10 text-gray-500 hover:border-white/20'
                }`}
              >
                {s}: {cnt}
              </button>
            );
          })}
        </div>
      </div>

      {/* Filter bar */}
      <div className="glass-card p-4 flex flex-wrap gap-3 items-center">
        {/* Search */}
        <div className="relative flex-1 min-w-[220px]">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">🔍</span>
          <input
            className="input-field pl-9 text-sm py-2"
            placeholder="Search location, description, type..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {/* Type filter */}
        <select
          className="input-field w-44 text-sm py-2"
          value={filters.issueType}
          onChange={(e) => setFilters((f) => ({ ...f, issueType: e.target.value }))}
        >
          <option value="">All Types</option>
          {['Theft', 'Drainage', 'Street Light', 'Climate'].map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>

        {/* Status filter */}
        <select
          className="input-field w-40 text-sm py-2"
          value={filters.status}
          onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
        >
          <option value="">All Status</option>
          {['Pending', 'In Progress', 'Resolved'].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>

        {/* Clear filters */}
        {(filters.issueType || filters.status || search) && (
          <button
            onClick={() => { setFilters({ issueType: '', status: '' }); setSearch(''); }}
            className="text-xs text-gray-500 hover:text-red-400 transition-colors"
          >
            ✕ Clear
          </button>
        )}
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex justify-center py-16">
          <div className="text-center space-y-3">
            <div className="spinner mx-auto" />
            <p className="text-gray-600 text-xs font-mono">LOADING REPORTS...</p>
          </div>
        </div>
      ) : filtered.length === 0 ? (
        <div className="glass-card p-16 text-center space-y-3">
          <div className="text-4xl">🔍</div>
          <p className="text-gray-400 font-medium">No reports found</p>
          <p className="text-gray-600 text-sm">Try adjusting your search or filters</p>
        </div>
      ) : (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/8 bg-dark-800/50">
                  {['Type', 'Location', 'Description', 'Reported By', 'Severity', 'Status', 'Date', ''].map((h) => (
                    <th key={h}
                      className="text-left text-[10px] font-semibold text-gray-600 uppercase
                                 tracking-widest px-4 py-3 whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((report, i) => (
                  <ReportRow key={report._id} report={report} index={i} />
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t border-white/5 text-xs text-gray-600 font-mono">
            {filtered.length} RECORDS · CLICK ROW TO EXPAND
          </div>
        </div>
      )}
    </div>
  );
}

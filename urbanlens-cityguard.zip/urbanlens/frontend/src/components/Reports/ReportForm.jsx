// ============================================================
// components/Reports/ReportForm.jsx
// Issue report submission form with embedded map location picker
// ============================================================
import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import api from '../../utils/api';

// Fix Leaflet's broken default icon path in Vite/Webpack builds
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// ── Issue type definitions ────────────────────────────────────
const ISSUE_TYPES = [
  { value: 'Theft',        label: 'Theft-Prone Area',    icon: '🔴', color: '#ef4444', hint: 'Crimes, muggings, unsafe zones' },
  { value: 'Drainage',     label: 'Drainage Problem',    icon: '🔵', color: '#3b82f6', hint: 'Blocked drains, flooding' },
  { value: 'Street Light', label: 'Street Light Failure',icon: '🟡', color: '#f59e0b', hint: 'Broken or missing lights' },
  { value: 'Climate',      label: 'Climatic Risk',       icon: '🟢', color: '#10b981', hint: 'Weather hazards, erosion' },
];

const SEVERITIES = [
  { value: 'Low',      label: 'Low',      color: '#22c55e' },
  { value: 'Medium',   label: 'Medium',   color: '#f59e0b' },
  { value: 'High',     label: 'High',     color: '#f97316' },
  { value: 'Critical', label: 'Critical', color: '#ef4444' },
];

// ── Map click handler component ───────────────────────────────
// Listens for clicks on the map and calls onPick with latlng
function LocationPicker({ onPick, position }) {
  useMapEvents({
    click: (e) => onPick(e.latlng),
  });
  return position ? <Marker position={[position.lat, position.lng]} /> : null;
}

// ── Main Component ────────────────────────────────────────────
export default function ReportForm() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    issueType:   '',
    location:    '',
    description: '',
    severity:    'Medium',
  });
  const [coords,  setCoords]  = useState(null);
  const [image,   setImage]   = useState(null);
  const [preview, setPreview] = useState('');
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');
  const [success, setSuccess] = useState(false);
  const [step,    setStep]    = useState(1); // 2-step form: Details → Location

  const handleChange = (e) =>
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImage(file);
    setPreview(URL.createObjectURL(file));
  };

  const removeImage = () => {
    setImage(null);
    setPreview('');
  };

  const handleMapClick = useCallback((latlng) => {
    setCoords(latlng);
  }, []);

  // ── Step 1 validation ─────────────────────────────────────
  const handleNextStep = () => {
    if (!form.issueType)                    return setError('Please select an issue type');
    if (!form.location.trim())              return setError('Please enter a location name');
    if (form.description.trim().length < 10) return setError('Description must be at least 10 characters');
    setError('');
    setStep(2);
  };

  // ── Form submission ───────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!coords) return setError('Please click on the map to pin the exact location');

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('issueType',   form.issueType);
      formData.append('location',    form.location);
      formData.append('description', form.description);
      formData.append('severity',    form.severity);
      formData.append('lat',         coords.lat);
      formData.append('lng',         coords.lng);
      if (image) formData.append('image', image);

      await api.post('/reports', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      setSuccess(true);
      setTimeout(() => navigate('/reports'), 2000);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit report. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // ── Success screen ────────────────────────────────────────
  if (success) {
    return (
      <div className="flex flex-col items-center justify-center py-24 space-y-4 animate-fade-in">
        <div className="w-20 h-20 rounded-full bg-green-500/15 border border-green-500/30
                        flex items-center justify-center text-4xl shadow-[0_0_30px_rgba(16,185,129,0.2)]">
          ✅
        </div>
        <h2 className="text-2xl font-bold text-white">Report Submitted!</h2>
        <p className="text-gray-500 text-sm text-center max-w-xs">
          Your issue has been logged. City teams will review it shortly.
        </p>
        <div className="flex items-center gap-2 text-xs text-gray-600 font-mono">
          <span className="w-2 h-2 rounded-full bg-accent-cyan animate-pulse" />
          Redirecting to reports list...
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">

      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Report an Issue</h1>
        <p className="text-gray-500 text-sm mt-0.5">
          Help improve your city by documenting urban problems
        </p>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-3">
        {[{ n: 1, label: 'Issue Details' }, { n: 2, label: 'Pin Location' }].map(({ n, label }) => (
          <div key={n} className="flex items-center gap-2">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
              step === n ? 'bg-accent-cyan text-dark-900' :
              step > n   ? 'bg-green-500 text-white' : 'bg-dark-500 text-gray-500'
            }`}>
              {step > n ? '✓' : n}
            </div>
            <span className={`text-sm ${step === n ? 'text-white' : 'text-gray-600'}`}>{label}</span>
            {n < 2 && <span className="text-gray-700 mx-1">→</span>}
          </div>
        ))}
      </div>

      {/* Error banner */}
      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 text-sm
                        rounded-lg px-4 py-3 flex items-center gap-2">
          <span>⚠</span> {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* ── Step 1: Issue Details ─────────────────────────── */}
        {step === 1 && (
          <div className="glass-card p-6 space-y-5 lg:col-span-2">
            {/* Issue type selector */}
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-3 uppercase tracking-wider">
                Issue Type *
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {ISSUE_TYPES.map((type) => (
                  <button
                    type="button"
                    key={type.value}
                    onClick={() => setForm((prev) => ({ ...prev, issueType: type.value }))}
                    className={`p-4 rounded-xl border text-left transition-all duration-200 ${
                      form.issueType === type.value
                        ? 'border-accent-cyan/60 bg-accent-cyan/8 text-white shadow-[0_0_15px_rgba(0,212,255,0.1)]'
                        : 'border-white/8 text-gray-400 hover:border-white/20 hover:text-gray-300'
                    }`}
                  >
                    <div className="text-2xl mb-2">{type.icon}</div>
                    <div className="text-sm font-medium leading-tight">{type.label}</div>
                    <div className="text-[10px] text-gray-600 mt-1 leading-tight">{type.hint}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Location text */}
              <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5 uppercase tracking-wider">
                  Location Name *
                </label>
                <input
                  name="location"
                  className="input-field"
                  placeholder="e.g. Main St near City Park"
                  value={form.location}
                  onChange={handleChange}
                  required
                />
              </div>

              {/* Severity */}
              <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5 uppercase tracking-wider">
                  Severity Level
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {SEVERITIES.map((s) => (
                    <button
                      type="button"
                      key={s.value}
                      onClick={() => setForm((prev) => ({ ...prev, severity: s.value }))}
                      className={`py-2 rounded-lg text-xs font-medium border transition-all ${
                        form.severity === s.value
                          ? 'text-white border-transparent'
                          : 'border-white/10 text-gray-500 hover:border-white/20'
                      }`}
                      style={form.severity === s.value ? { background: `${s.color}25`, borderColor: `${s.color}50`, color: s.color } : {}}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1.5 uppercase tracking-wider">
                Description * <span className="normal-case text-gray-600">(min. 10 chars)</span>
              </label>
              <textarea
                name="description"
                className="input-field min-h-[120px] resize-none"
                placeholder="Describe the issue in detail. Include when it occurs, how it affects people, and any relevant context..."
                value={form.description}
                onChange={handleChange}
                required
              />
              <div className="text-right text-[10px] text-gray-600 mt-1">
                {form.description.length} / 1000
              </div>
            </div>

            {/* Image upload */}
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1.5 uppercase tracking-wider">
                Photo Evidence (Optional)
              </label>
              {preview ? (
                <div className="relative">
                  <img src={preview} alt="Preview"
                    className="w-full h-40 object-cover rounded-xl border border-white/10" />
                  <button type="button" onClick={removeImage}
                    className="absolute top-2 right-2 w-7 h-7 rounded-full bg-dark-900/80 text-red-400
                               hover:bg-red-500/20 transition-colors flex items-center justify-center text-sm">
                    ✕
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => document.getElementById('imgInput').click()}
                  className="border-2 border-dashed border-white/10 rounded-xl p-8
                             text-center cursor-pointer hover:border-accent-cyan/30
                             hover:bg-accent-cyan/3 transition-all duration-200 group"
                >
                  <div className="text-3xl mb-2 group-hover:scale-110 transition-transform">📷</div>
                  <p className="text-sm text-gray-500">Click to upload photo</p>
                  <p className="text-xs text-gray-700 mt-1">JPG, PNG, WEBP · Max 5MB</p>
                </div>
              )}
              <input id="imgInput" type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
            </div>

            <button type="button" onClick={handleNextStep} className="btn-primary w-full">
              Continue → Pin Location
            </button>
          </div>
        )}

        {/* ── Step 2: Map Location Picker ───────────────────── */}
        {step === 2 && (
          <>
            {/* Summary of step 1 */}
            <div className="glass-card p-5 space-y-4 self-start">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-gray-200">Report Summary</h3>
                <button onClick={() => setStep(1)} className="text-xs text-accent-cyan hover:underline">
                  ← Edit
                </button>
              </div>
              <div className="space-y-3">
                {[
                  { label: 'Type',     value: form.issueType },
                  { label: 'Location', value: form.location  },
                  { label: 'Severity', value: form.severity  },
                ].map(({ label, value }) => (
                  <div key={label} className="flex items-start gap-2">
                    <span className="text-xs text-gray-600 w-16 flex-shrink-0 pt-0.5">{label}</span>
                    <span className="text-sm text-gray-200">{value}</span>
                  </div>
                ))}
                <div>
                  <span className="text-xs text-gray-600">Description</span>
                  <p className="text-sm text-gray-400 mt-0.5 line-clamp-3">{form.description}</p>
                </div>
              </div>

              {/* Coordinates display */}
              <div className={`p-3 rounded-lg border transition-all ${
                coords
                  ? 'bg-accent-cyan/5 border-accent-cyan/20'
                  : 'bg-dark-800 border-white/5'
              }`}>
                {coords ? (
                  <div>
                    <div className="flex items-center gap-2 text-accent-cyan text-xs font-mono mb-1">
                      <span>📍</span> Location Pinned
                    </div>
                    <div className="text-xs font-mono text-gray-400">
                      {coords.lat.toFixed(6)}, {coords.lng.toFixed(6)}
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-gray-600 text-center">
                    ← Click on the map to pin location
                  </p>
                )}
              </div>

              <button
                onClick={handleSubmit}
                disabled={loading || !coords}
                className="btn-primary w-full disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="w-4 h-4 border-2 border-dark-900/30 border-t-dark-900 rounded-full animate-spin" />
                    Submitting...
                  </span>
                ) : !coords ? (
                  'Pin location on map first'
                ) : (
                  '✓ Submit Report'
                )}
              </button>
            </div>

            {/* Map */}
            <div className="glass-card overflow-hidden flex flex-col">
              <div className="px-4 py-2.5 border-b border-white/5 flex items-center gap-2">
                <span className="text-xs font-mono text-gray-500">CLICK MAP TO PIN LOCATION</span>
                {coords && (
                  <span className="ml-auto text-xs font-mono text-accent-cyan">● PINNED</span>
                )}
              </div>
              <MapContainer
                center={[20.5937, 78.9629]}
                zoom={5}
                style={{ flex: 1, minHeight: '460px' }}
              >
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='© <a href="https://www.openstreetmap.org/">OpenStreetMap</a>'
                />
                <LocationPicker onPick={handleMapClick} position={coords} />
              </MapContainer>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

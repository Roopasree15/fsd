# 🏙 UrbanLens & CityGuard

> Smart City Monitoring System — MERN Stack

A full-stack web application for reporting and tracking urban issues including theft-prone areas, drainage problems, street light failures, and climatic risks.

---

## 📸 Features

| Feature | Details |
|---|---|
| **Authentication** | JWT login/signup, role-based (User & Admin) |
| **Dashboard** | KPI cards, bar/donut charts, recent activity feed |
| **Issue Reporting** | 2-step form with map location picker + image upload |
| **Map View** | Leaflet map, color-coded circle markers, popups |
| **Admin Panel** | Filter, edit status/severity/notes, delete reports |
| **Dark Theme** | Glassmorphism cards, cyan accent, animated UI |

---

## 🗂 Project Structure

```
urbanlens/
├── backend/                   # Node.js + Express API
│   ├── server.js              # Entry point
│   ├── .env.example           # Environment variable template
│   ├── models/
│   │   ├── User.js            # User schema (bcrypt password hashing)
│   │   └── Report.js          # Report schema (all issue types)
│   ├── middleware/
│   │   ├── auth.js            # JWT protect + adminOnly guards
│   │   └── upload.js          # Multer image upload config
│   └── routes/
│       ├── auth.js            # POST /signup, /login  GET /me
│       └── reports.js         # Full CRUD + /stats + /mine
│
└── frontend/                  # React + Vite + Tailwind
    ├── index.html
    ├── vite.config.js         # Dev server with API proxy
    ├── tailwind.config.js     # Custom dark theme tokens
    └── src/
        ├── App.jsx            # Router + auth guards
        ├── index.css          # Global styles + Leaflet dark theme
        ├── main.jsx
        ├── context/
        │   └── AuthContext.jsx   # Global auth state (login/signup/logout)
        ├── utils/
        │   └── api.js            # Axios instance + auth interceptor
        └── components/
            ├── Auth/
            │   ├── Login.jsx
            │   └── Signup.jsx
            ├── Layout/
            │   └── Layout.jsx    # Sidebar + topbar shell
            ├── Dashboard/
            │   └── Dashboard.jsx # Charts + stats + recent activity
            ├── Reports/
            │   ├── ReportForm.jsx   # 2-step form with map picker
            │   └── ReportsList.jsx  # Filterable report table
            ├── Map/
            │   └── MapView.jsx      # Full map with markers
            └── Admin/
                └── AdminPanel.jsx   # Admin CRUD table + edit modal
```

---

## 🚀 Local Setup

### Prerequisites

- **Node.js** v18 or higher
- **MongoDB** (local install) or free [MongoDB Atlas](https://cloud.mongodb.com) cluster
- **npm** or **yarn**

---

### 1. Clone / extract the project

```bash
cd urbanlens
```

---

### 2. Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Copy environment template
cp .env.example .env
```

Edit `.env` with your values:

```env
MONGO_URI=mongodb://localhost:27017/urbanlens
JWT_SECRET=your_long_random_secret_here
PORT=5000
CLIENT_URL=http://localhost:5173
```

Start the backend:

```bash
# Development (auto-reload)
npm run dev

# Production
npm start
```

Backend runs at → **http://localhost:5000**

---

### 3. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

Frontend runs at → **http://localhost:5173**

The Vite dev server proxies all `/api` and `/uploads` requests to the backend automatically.

---

### 4. Create an Admin User

1. Sign up normally through the UI
2. Open MongoDB Compass or the `mongosh` shell:

```js
use urbanlens

db.users.updateOne(
  { email: "your@email.com" },
  { $set: { role: "admin" } }
)
```

3. Log out and log back in — the Admin Panel will appear in the sidebar

---

## 📡 API Reference

### Authentication

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/signup` | ❌ | Register new user |
| POST | `/api/auth/login`  | ❌ | Login, returns JWT |
| GET  | `/api/auth/me`     | ✅ | Get current user |

### Reports

| Method | Endpoint | Auth | Role | Description |
|--------|----------|------|------|-------------|
| POST   | `/api/reports`        | ✅ | User  | Submit new report (multipart/form-data) |
| GET    | `/api/reports`        | ❌ | —     | Get all reports (filterable) |
| GET    | `/api/reports/stats`  | ✅ | Any   | Dashboard statistics |
| GET    | `/api/reports/mine`   | ✅ | User  | Current user's reports |
| GET    | `/api/reports/:id`    | ❌ | —     | Single report |
| PUT    | `/api/reports/:id`    | ✅ | Admin | Update status/severity/note |
| DELETE | `/api/reports/:id`    | ✅ | Admin | Delete report |

#### Query Parameters for `GET /api/reports`
- `issueType` — filter by: `Theft`, `Drainage`, `Street Light`, `Climate`
- `status` — filter by: `Pending`, `In Progress`, `Resolved`
- `location` — fuzzy search location string
- `page` — page number (default: 1)
- `limit` — results per page (default: 50)

---

## 🗺 Map Color Legend

| Color | Issue Type |
|-------|-----------|
| 🔴 Red    | Theft-Prone Area |
| 🔵 Blue   | Drainage Problem |
| 🟡 Yellow | Street Light Failure |
| 🟢 Green  | Climatic Risk |

Marker **border color** reflects status: Yellow = Pending, Blue = In Progress, Green = Resolved.
Marker **size** reflects severity: Critical > High > Medium > Low.

---

## 🛠 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite, Tailwind CSS |
| Routing | React Router v6 |
| HTTP | Axios |
| Charts | Recharts |
| Map | Leaflet + React-Leaflet |
| Backend | Node.js, Express.js |
| Database | MongoDB + Mongoose |
| Auth | JWT + bcryptjs |
| File Upload | Multer |

---

## 🔧 Common Issues

**Map tiles not loading?**
The Leaflet tiles use OpenStreetMap — requires internet access.

**Images not showing after upload?**
Make sure the backend `/uploads` folder exists. It's created automatically on first start.

**CORS errors?**
Ensure `CLIENT_URL` in backend `.env` matches your frontend URL exactly.

**MongoDB connection refused?**
Start MongoDB locally: `mongod --dbpath /data/db`
Or use a MongoDB Atlas connection string.

// ============================================================
// models/Report.js - Mongoose schema for city issue reports
// ============================================================
const mongoose = require('mongoose');

const ReportSchema = new mongoose.Schema({
  // The user who submitted this report
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  // Type of urban issue being reported
  issueType: {
    type: String,
    enum: ['Theft', 'Drainage', 'Street Light', 'Climate'],
    required: [true, 'Issue type is required'],
  },
  // Human-readable location description
  location: {
    type: String,
    required: [true, 'Location is required'],
    trim: true,
  },
  // GPS coordinates for map display
  coordinates: {
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
  },
  // Detailed description of the issue
  description: {
    type: String,
    required: [true, 'Description is required'],
    trim: true,
    minlength: 10,
    maxlength: 1000,
  },
  // Optional image (stored as filename in /uploads)
  image: {
    type: String,
    default: null,
  },
  // Current resolution status
  status: {
    type: String,
    enum: ['Pending', 'In Progress', 'Resolved'],
    default: 'Pending',
  },
  // Admin notes for status updates
  adminNote: {
    type: String,
    default: '',
  },
  // Severity level computed from issue type
  severity: {
    type: String,
    enum: ['Low', 'Medium', 'High', 'Critical'],
    default: 'Medium',
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Update the updatedAt timestamp before every save
ReportSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Report', ReportSchema);

// ============================================================
// routes/reports.js - Report CRUD routes
// POST   /api/reports        → Submit new report (auth required)
// GET    /api/reports        → Get all reports (public)
// GET    /api/reports/mine   → Get current user's reports
// GET    /api/reports/stats  → Get dashboard statistics
// GET    /api/reports/:id    → Get single report
// PUT    /api/reports/:id    → Update report status (admin only)
// DELETE /api/reports/:id    → Delete report (admin only)
// ============================================================
const express = require('express');
const router = express.Router();
const Report = require('../models/Report');
const { protect, adminOnly } = require('../middleware/auth');
const upload = require('../middleware/upload');

// ── POST /api/reports ─────────────────────────────────────────
// Submit a new issue report (authenticated users only)
router.post('/', protect, upload.single('image'), async (req, res) => {
  try {
    const { issueType, location, description, lat, lng, severity } = req.body;

    // Validate required fields
    if (!issueType || !location || !description || !lat || !lng) {
      return res.status(400).json({ message: 'Please fill in all required fields' });
    }

    const report = await Report.create({
      user: req.user._id,
      issueType,
      location,
      description,
      coordinates: { lat: parseFloat(lat), lng: parseFloat(lng) },
      severity: severity || 'Medium',
      image: req.file ? req.file.filename : null, // Save filename if image was uploaded
    });

    // Populate user info before sending response
    await report.populate('user', 'name email');

    res.status(201).json({ message: 'Report submitted successfully', report });
  } catch (err) {
    console.error('Create report error:', err);
    res.status(500).json({ message: 'Failed to submit report' });
  }
});

// ── GET /api/reports ──────────────────────────────────────────
// Get all reports with optional filtering (public access)
router.get('/', async (req, res) => {
  try {
    const { issueType, status, location, page = 1, limit = 50 } = req.query;

    // Build query filter
    const filter = {};
    if (issueType) filter.issueType = issueType;
    if (status) filter.status = status;
    if (location) filter.location = { $regex: location, $options: 'i' };

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const reports = await Report.find(filter)
      .populate('user', 'name email')
      .sort({ createdAt: -1 }) // Newest first
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Report.countDocuments(filter);

    res.json({
      reports,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / parseInt(limit)),
    });
  } catch (err) {
    console.error('Get reports error:', err);
    res.status(500).json({ message: 'Failed to fetch reports' });
  }
});

// ── GET /api/reports/stats ────────────────────────────────────
// Dashboard statistics (counts by status and issue type)
router.get('/stats', protect, async (req, res) => {
  try {
    // For regular users, only count their own reports
    // For admins, count all reports
    const matchStage = req.user.role === 'admin'
      ? {}
      : { user: req.user._id };

    const [statusStats, typeStats, recent] = await Promise.all([
      // Count by status
      Report.aggregate([
        { $match: matchStage },
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),
      // Count by issue type
      Report.aggregate([
        { $match: matchStage },
        { $group: { _id: '$issueType', count: { $sum: 1 } } },
      ]),
      // 5 most recent reports
      Report.find(matchStage)
        .populate('user', 'name')
        .sort({ createdAt: -1 })
        .limit(5),
    ]);

    res.json({ statusStats, typeStats, recent });
  } catch (err) {
    console.error('Stats error:', err);
    res.status(500).json({ message: 'Failed to fetch stats' });
  }
});

// ── GET /api/reports/mine ─────────────────────────────────────
// Get only the current user's reports
router.get('/mine', protect, async (req, res) => {
  try {
    const reports = await Report.find({ user: req.user._id })
      .sort({ createdAt: -1 });
    res.json({ reports });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch your reports' });
  }
});

// ── GET /api/reports/:id ──────────────────────────────────────
// Get a single report by ID
router.get('/:id', async (req, res) => {
  try {
    const report = await Report.findById(req.params.id).populate('user', 'name email');
    if (!report) {
      return res.status(404).json({ message: 'Report not found' });
    }
    res.json({ report });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch report' });
  }
});

// ── PUT /api/reports/:id ──────────────────────────────────────
// Update report status and add admin note (admin only)
router.put('/:id', protect, adminOnly, async (req, res) => {
  try {
    const { status, adminNote, severity } = req.body;

    const report = await Report.findByIdAndUpdate(
      req.params.id,
      {
        ...(status && { status }),
        ...(adminNote !== undefined && { adminNote }),
        ...(severity && { severity }),
        updatedAt: Date.now(),
      },
      { new: true, runValidators: true } // Return updated document
    ).populate('user', 'name email');

    if (!report) {
      return res.status(404).json({ message: 'Report not found' });
    }

    res.json({ message: 'Report updated successfully', report });
  } catch (err) {
    console.error('Update report error:', err);
    res.status(500).json({ message: 'Failed to update report' });
  }
});

// ── DELETE /api/reports/:id ───────────────────────────────────
// Delete a report (admin only)
router.delete('/:id', protect, adminOnly, async (req, res) => {
  try {
    const report = await Report.findByIdAndDelete(req.params.id);
    if (!report) {
      return res.status(404).json({ message: 'Report not found' });
    }
    res.json({ message: 'Report deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete report' });
  }
});

module.exports = router;

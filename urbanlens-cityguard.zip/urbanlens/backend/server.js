// ============================================================
// server.js - Main Express server entry point
// ============================================================
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables from .env file
dotenv.config();

// Import route files
const authRoutes = require('./routes/auth');
const reportRoutes = require('./routes/reports');

// Initialize Express app
const app = express();

// ── Middleware ───────────────────────────────────────────────
// Parse incoming JSON requests
app.use(express.json());

// Enable CORS so the React frontend can communicate with this API
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true,
}));

// Serve uploaded images as static files at /uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── Routes ───────────────────────────────────────────────────
app.use('/api/auth', authRoutes);     // Authentication routes
app.use('/api/reports', reportRoutes); // Report CRUD routes

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'UrbanLens API is running' });
});

// ── Database Connection ──────────────────────────────────────
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/urbanlens')
  .then(() => {
    console.log('✅ Connected to MongoDB');
    // Start the server only after DB connection succeeds
    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('❌ MongoDB connection error:', err.message);
    process.exit(1);
  });

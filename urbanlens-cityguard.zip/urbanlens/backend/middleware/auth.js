// ============================================================
// middleware/auth.js - JWT authentication & role guard
// ============================================================
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// ── Protect Middleware ────────────────────────────────────────
// Verifies the JWT token sent in the Authorization header.
// Attaches the decoded user to req.user for downstream use.
const protect = async (req, res, next) => {
  try {
    // Expect header: "Authorization: Bearer <token>"
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'No token, authorization denied' });
    }

    const token = authHeader.split(' ')[1];

    // Verify and decode the token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Fetch the user from DB (without the password field)
    const user = await User.findById(decoded.id).select('-password');
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }

    req.user = user; // Attach user to request object
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Token is not valid' });
  }
};

// ── Admin Only Middleware ─────────────────────────────────────
// Must be used AFTER protect middleware.
// Blocks access if the authenticated user is not an admin.
const adminOnly = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ message: 'Admin access required' });
  }
};

module.exports = { protect, adminOnly };
